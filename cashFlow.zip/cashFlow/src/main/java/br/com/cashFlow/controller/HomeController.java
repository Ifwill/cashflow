package br.com.cashFlow.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

	
@Controller
public class HomeController {

	@GetMapping("/")
	public ModelAndView index() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home/index.html");
		mv.addObject("msg","Mensagem teste do thymeleaf");
		mv.addObject("gu", "gustavo cop");
		return mv;
	}
}
